//
//  ViewController.h
//  rest
//
//  Created by Dinesh Jaganathan on 13/10/16.
//  Copyright © 2016 Greens. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

{
    NSMutableData * mut;
    NSDictionary * dc;
    
}
@end

